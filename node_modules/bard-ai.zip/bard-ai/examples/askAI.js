import Bard, { askAI } from "bard-ai";

await Bard.init("ewjdIX2ym7dVOwfL_4dBWYDKwWlUXyLO9sys-YAhxUOgUvn4GhXg5VDe3842vv6TC0-uEA.");

console.log(await askAI("Olá mundo!"));
